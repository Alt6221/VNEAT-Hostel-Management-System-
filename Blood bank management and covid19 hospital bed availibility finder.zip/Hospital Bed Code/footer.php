
                <div class="clear"></div>
            </div>
            <!-- // #container -->
        </div>	
        <!-- // #containerHolder -->
        
        <p id="footer">Hospital Bed Management System. &copy; 2019. All Rights Reserved - Pranav Roy</p>
    </div>
    <!-- // #wrapper -->
</body>
</html>